
import './App.css';
import Smile from './component/Smile';

function App() {
  return (
    <div className="App">
      <Smile/>
    </div>
  );
}

export default App;
