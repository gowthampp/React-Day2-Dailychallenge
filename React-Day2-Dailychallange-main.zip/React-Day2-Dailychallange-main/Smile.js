import React from 'react'

function Smile() {
  return (
    <div>
      <h1>Smile component</h1>
      <p>its a functional component</p>
      <img src="https://static.vecteezy.com/system/resources/thumbnails/002/592/172/small/smile-emoji-pop-art-line-style-icon-free-vector.jpg"alt="smile"></img>
    </div>
  )
}

export default Smile